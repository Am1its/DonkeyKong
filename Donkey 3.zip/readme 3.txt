Donkey Kong Project #3:

Created by Ziv Balassiano and(207033606) Amit Oved(209140664).

This project is a console-based version of the classic Donkey Kong game. This exercise introduces two new features:

Saving: The game records each key step in .steps and .result files for each board that is loaded.
Loading: The game can replay recorded games based on these saved files, optionally verifying the results against expected outcomes.

Features Implemented
Core Features
Loading Screens: The game reads .screen files to initialize the stage.
Game Elements: Dynamic behavior of barrels, ghosts, and player movement based on predefined rules.
Saving and Loading:
When running in save mode (-save), game steps and results are recorded to files.
In load mode (-load), the game plays back recorded steps.
Silent mode (-silent) for load testing, validating that results match expectations.

step file :
1.seed file(each board has unique seed number)
2. score,mario life,color mode
...
iteration number , mario valid key 

results file : 
iteration , status
has to be finished with GameOver/Win.

Bonus Features:

Color Support: when playing in color mode, the load of the screen will be playback with color
Enhanced Ghost Behavior: Ghosts will behave by the algorhitim of comparing the height of the ghost to mario, and trying to be equal to him.

if no arguments in the main, the game will run as default without saving to files
if no files exsits (board,steps,results), an excpetion error will be shown in run time.

in silent mode, the game will be playing behinde the scene, without printing, and comparing the actual resutls to the expected results from the results file.
if there are more results in the expected results  than in the actual game results, it will skip the test and send error of fail.


we have sent 3  pre played(without color) board : winning the first 2 boards, and losing the third one


